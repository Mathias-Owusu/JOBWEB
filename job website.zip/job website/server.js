const express = require('express');
const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.static('public'));  // To serve static files like HTML, CSS, JS

// Dummy endpoint to get job data (later you can replace this with a database call)
app.get('/jobs', (req, res) => {
    const jobs = [
        { title: "Software Engineer", company: "TechCorp", location: "Remote" },
        { title: "Product Manager", company: "ProductX", location: "New York" },
        { title: "Web Developer", company: "WebWorks", location: "San Francisco" },
    ];
    res.json(jobs);  // Send jobs data as JSON
});

// Start server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
