const letters = document.getElementById('animated-letters').textContent.split('');
const animatedLetters = document.getElementById('animated-letters');

animatedLetters.innerHTML = '';

letters.forEach((letter) => {
  const span = document.createElement('span');
  span.textContent = letter;
  span.classList.add('animated-letter');
  animatedLetters.appendChild(span);
});
