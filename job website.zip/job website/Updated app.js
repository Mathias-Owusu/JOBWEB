// Function to search jobs
function searchJobs() {
    const searchTerm = document.getElementById('job-search').value.toLowerCase();

    fetch('/jobs')  // Get jobs from the server
        .then(response => response.json())
        .then(jobs => {
            const filteredJobs = jobs.filter(job => 
                job.title.toLowerCase().includes(searchTerm) ||
                job.company.toLowerCase().includes(searchTerm) ||
                job.location.toLowerCase().includes(searchTerm)
            );
            displayJobs(filteredJobs);
        })
        .catch(err => console.error('Error fetching jobs:', err));
}
