const loginForm = document.getElementById('login-form');
const createAccountLink = document.getElementById('create-account-link');
const forgotPasswordLink = document.getElementById('forgot-password-link');
const createAccountForm = document.getElementById('create-account-form');
const forgotPasswordForm = document.getElementById('forgot-password-form');
const resetPasswordForm = document.getElementById('reset-password-form');

loginForm.style.display = 'block';

createAccountLink.addEventListener('click', (e) => {
    e.preventDefault();
    loginForm.style.display = 'none';
    createAccountForm.style.display = 'block';
});

forgotPasswordLink.addEventListener('click', (e) => {
    e.preventDefault();
    loginForm.style.display = 'none';
    forgotPasswordForm.style.display = 'block';
});

createAccountForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const createUsername = document.getElementById('create-username').value;
    const createEmail = document.getElementById('create-email').value;
    const createPassword = document.getElementById('create-password').value;
    const createConfirmPassword = document.getElementById('create-confirm-password').value;

    if (createPassword !== createConfirmPassword) {
        alert('Passwords do not match.');
        return;
    }

    // Create account logic here
    console.log(`Account created for ${createUsername} with email ${createEmail} and password ${createPassword}`);
});

forgotPasswordForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const forgotUsername = document.getElementById('forgot-username').value;

    // Forgot password logic here
    console.log(`Password reset link sent to ${forgotUsername}`);
    resetPasswordForm.style.display = 'block';
    forgotPasswordForm.style.display = 'none';
});

resetPasswordForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const resetPassword = document.getElementById('reset-password').value;
    const resetConfirmPassword = document.getElementById('reset-confirm-password').value;

    if (resetPassword !== resetConfirmPassword) {
        alert('Passwords do not match.');
        return;
    }

    // Reset password logic here
    console.log(`Password reset successfully`);
});
