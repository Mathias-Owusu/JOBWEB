//In this section, you'll write JavaScript to search for jobs and display them
// Placeholder job data
const jobs = [
    { title: "Software Engineer", company: "TechCorp", location: "Remote" },
    { title: "Product Manager", company: "ProductX", location: "New York" },
    { title: "Web Developer", company: "WebWorks", location: "San Francisco" },
    // Add more jobs as needed
];

// Function to search jobs
function searchJobs() {
    const searchTerm = document.getElementById('job-search').value.toLowerCase();
    const filteredJobs = jobs.filter(job => 
        job.title.toLowerCase().includes(searchTerm) ||
        job.company.toLowerCase().includes(searchTerm) ||
        job.location.toLowerCase().includes(searchTerm)
    );

    displayJobs(filteredJobs);
}

// Function to display job listings
function displayJobs(jobs) {
    const jobList = document.getElementById('jobs');
    jobList.innerHTML = '';  // Clear previous listings

    if (jobs.length === 0) {
        jobList.innerHTML = '<li>No jobs found.</li>';
    } else {
        jobs.forEach(job => {
            const jobItem = document.createElement('li');
            jobItem.textContent = `${job.title} at ${job.company} (${job.location})`;
            jobList.appendChild(jobItem);
        });
    }
}
